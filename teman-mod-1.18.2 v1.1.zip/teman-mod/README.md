# Teman (Fabric 1.18.2)

Teman ala Steve: muncul otomatis, bisa diajak ngobrol lewat chat, nebang kayu, nambang ore.

## Build
1. Java 17 + (Gradle 7.4+). Kalau belum ada gradlew: jalankan `gradle wrapper --gradle-version 7.4.2`
   atau salin folder `src`, `build.gradle`, `gradle.properties` ke template Fabric 1.18.2.
2. `./gradlew build`  -> hasil di `build/libs/teman-1.0.0.jar`
3. Taruh jar di folder `mods` bersama Fabric Loader 0.14.x + Fabric API 0.76.1+1.18.2.

## Pakai
- Muncul otomatis saat pertama kali masuk dunia. Hilang/mati: `/teman panggil`.
- Ketik di chat biasa: "ambil kayu", "ambil 20 kayu", "tambang", "tambang diamond", "cari besi 10",
  "ikut aku", "tunggu di sini", "stop", "bawa apa?", "kasih hasilnya", "bantuan".
- Klik kanan temanmu untuk menyapa.

## Fitur lengkap (v2)
- Tugas: kayu (sekalian tanam bibit), tambang (obor otomatis, hindari lava), kebun (panen + tanam ulang),
  jaga/pengawal, simpan ke peti, set rumah + pulang, ulangi tugas terakhir.
- Perbekalan: klik kanan teman sambil pegang makanan atau obor. Dia makan sendiri saat darahnya turun.
- Ingatan: nama panggilan pemain ("panggil aku Rafi"), nama teman ("ganti namamu jadi Joko"),
  level pertemanan, jumlah tugas selesai, dan pertanyaan lanjutan ("Mau aku ambilin kayu?" -> "iya").
