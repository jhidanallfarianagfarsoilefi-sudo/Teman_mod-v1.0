package com.teman;

import com.teman.entity.CompanionEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

import java.util.List;

public class TemanMod implements ModInitializer {
    public static final String MOD_ID = "teman";
    private static final String SPAWN_TAG = "teman_sudah_muncul";

    public static final EntityType<CompanionEntity> COMPANION = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(MOD_ID, "teman"),
            FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, CompanionEntity::new)
                    .dimensions(EntityDimensions.fixed(0.6f, 1.8f))
                    .trackRangeBlocks(64)
                    .build());

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(COMPANION, CompanionEntity.createAttributes());

        // Muncul otomatis saat pemain pertama kali masuk dunia
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity p = handler.player;
            if (!p.getScoreboardTags().contains(SPAWN_TAG)) {
                p.addScoreboardTag(SPAWN_TAG);
                server.execute(() -> spawnFor(p));
            }
        });

        // /teman panggil -> panggil temanmu (atau buat baru kalau hilang)
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) ->
                dispatcher.register(CommandManager.literal("teman")
                        .then(CommandManager.literal("panggil").executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayer();
                            List<CompanionEntity> list = findCompanions(p, 256);
                            if (list.isEmpty()) {
                                spawnFor(p);
                            } else {
                                list.get(0).teleportNear(p);
                                list.get(0).say("Aku datang, {p}!");
                            }
                            return 1;
                        }))));
    }

    public static CompanionEntity spawnFor(ServerPlayerEntity p) {
        ServerWorld w = (ServerWorld) p.world;
        CompanionEntity c = COMPANION.create(w);
        if (c == null) return null;
        c.setOwner(p);
        c.teleportNear(p);
        w.spawnEntity(c);
        c.addSupply(new ItemStack(Items.TORCH, 16));
        c.addSupply(new ItemStack(Items.BREAD, 8));
        c.say("Halo {p}! Aku {n}, temanmu. Ketik 'bantuan' di chat buat lihat apa aja yang bisa aku kerjakan.");
        return c;
    }

    public static List<CompanionEntity> findCompanions(ServerPlayerEntity p, double range) {
        return p.world.getEntitiesByClass(CompanionEntity.class,
                p.getBoundingBox().expand(range),
                c -> c.isAlive() && p.getUuid().equals(c.getOwnerUuid()));
    }
}
