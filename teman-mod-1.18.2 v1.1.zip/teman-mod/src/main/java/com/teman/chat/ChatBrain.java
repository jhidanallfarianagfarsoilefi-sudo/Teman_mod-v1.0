package com.teman.chat;

import com.teman.TemanMod;
import com.teman.entity.CompanionEntity;
import com.teman.entity.CompanionEntity.Mode;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Otak obrolan berbasis aturan: kalimat pemain dibersihkan, dicocokkan ke "maksud" (intent)
 * lewat kata kunci, lalu dibalas dengan salah satu dari banyak variasi kalimat.
 * Placeholder: {p}=nama pemain, {n}=nama teman, {h}=darah teman.
 */
public final class ChatBrain {
    private static final Random RNG = new Random();
    private static final Pattern NUM = Pattern.compile(" (\\d{1,3}) ");
    private static final Pattern NICK = Pattern.compile("(?iu)panggil\\s+(?:aku|saya|gue|gua)\\s+(?:dengan\\s+|jadi\\s+)?([\\p{L}0-9]{2,16})");
    private static final Pattern RENAME = Pattern.compile("(?iu)(?:ganti\\s+nama\\s*mu|ganti\\s+nama\\s+kamu|nama\\s*mu\\s+jadi|nama\\s+kamu\\s+jadi|panggil\\s+kamu\\s+(?:jadi|menjadi))\\s+([\\p{L}0-9]{2,16})");
    private static final Set<String> RESERVED = Set.of("dong", "ya", "nanti", "dulu", "kalau", "kalo", "kesini", "sini", "saja", "aja", "lagi", "jadi", "dengan");

    private ChatBrain() {}

    // ======================================================== kamus balasan
    private static final String[] GREET = {
        "Halo {p}! Ada yang bisa aku bantu?", "Hai {p}! Siap kerja kapan aja.",
        "Yo {p}! Hari ini mau ngapain? Nebang kayu atau nambang?", "Halo! Senang ketemu kamu lagi, {p}." };
    private static final String[] NAME = {
        "Aku {n}, temanmu di dunia ini!", "Namaku {n}. Aku partner kerjamu, {p}.",
        "Aku {n}! Tukang kayu merangkap penambang, siap dipanggil kapan aja." };
    private static final String[] HOW = {
        "Aku baik-baik aja! Darahku {h}/20. Kamu sendiri gimana, {p}?", "Sehat kok, makasih udah nanya!",
        "Lagi semangat nih, siap kerja. Kamu gimana?" };
    private static final String[] HOW_HURT = {
        "Aku lagi lumayan luka... darahku tinggal {h}/20. Tapi masih kuat kok!",
        "Agak babak belur, {p}. Darahku {h}/20. Nanti juga pulih pelan-pelan." };
    private static final String[] THANKS = {
        "Sama-sama, {p}!", "Santai aja, kita kan tim.", "Siap! Kapan aja butuh bantuan, bilang ya.", "Dengan senang hati!" };
    private static final String[] PRAISE = {
        "Hehe, makasih {p}! Jadi semangat.", "Wah, makasih! Aku bakal kerja lebih keras.", "Ah, kamu bisa aja. Tapi senang dengernya!" };
    private static final String[] SORRY = {
        "Nggak apa-apa kok, {p}. Santai aja.", "Udah, aku nggak marah. Yuk lanjut!" };
    private static final String[] HURT = {
        "Aduh... itu agak nyakitin, {p}. Tapi aku tetap teman kamu kok.", "Hiks. Aku udah berusaha sebaik mungkin...",
        "Oke, aku catat. Nanti aku kerja lebih baik." };
    private static final String[] JOKES = {
        "Kenapa creeper nggak punya teman? Soalnya tiap deket, hubungannya langsung meledak.",
        "Kenapa penambang nggak pernah galau? Karena dia selalu gali lebih dalam.",
        "Zombie ke dokter: Dok, badan saya lemas. Dokter: Wajar, kamu kan udah mati.",
        "Kenapa skeleton nggak pernah ikut pesta? Karena nggak ada daging buat dibawa... eh, nggak ada yang diajak ngobrol.",
        "Aku mau ngelawak, tapi takutnya garing kayak kayu oak yang kelamaan dijemur." };
    private static final String[] FACTS = {
        "Tahu nggak? Di versi 1.18 diamond paling banyak muncul di sekitar Y -59.",
        "Tahu nggak? Creeper takut sama kucing.", "Tahu nggak? Emerald cuma muncul di biom pegunungan.",
        "Tahu nggak? Batu bara paling banyak ada di ketinggian sekitar Y 96 ke atas.",
        "Tahu nggak? Redstone paling banyak ada di dasar dunia, sekitar Y -59.",
        "Tahu nggak? Lapis lazuli paling banyak muncul di sekitar Y 0." };
    private static final String[] MOBS = {
        "Monster itu bahaya, tapi tenang, aku bantu jagain kamu. Cuma creeper aja yang aku hindari.",
        "Kalau dengar suara desis, itu creeper! Langsung mundur!", "Zombie dan skeleton biasanya keluar pas malam atau di gua gelap. Pasang obor ya.",
        "Tenang {p}, kalau ada musuh yang nyerang, aku maju duluan." };
    private static final String[] NETHER = {
        "Nether itu panas dan berbahaya. Bawa makanan, armor, dan balok buat nutup lava ya.",
        "Kalau mau ke Nether, siapin obsidian dulu. Aku bisa bantu nambang bahan lainnya." };
    private static final String[] HOUSE = {
        "Bikin rumah? Boleh! Aku bisa bantu ngumpulin kayu dulu. Bilang aja \"ambil 64 kayu\".",
        "Rumah yang bagus mulai dari bahan yang cukup. Mau aku ambilin kayu?" };
    private static final String[] FOOD = {
        "Jangan lupa makan, {p}. Perut kosong bikin lemas pas lagi nambang.", "Daging panggang itu makanan murah tapi mengenyangkan.",
        "Aku sih nggak pernah lapar. Tapi kamu harus makan teratur ya." };
    private static final String[] SLEEP = {
        "Tidur itu bisa ngelewatin malam dan nge-set titik respawn. Pakai kasur ya.",
        "Kalau udah malam, mending tidur daripada diganggu zombie." };
    private static final String[] FRIEND = {
        "Tentu, kita teman, {p}!", "Teman terbaik di dunia kotak-kotak ini, hehe.", "Aku senang bisa nemenin kamu." };
    private static final String[] BYE = {
        "Dadah {p}! Hati-hati ya.", "Sampai ketemu lagi! Aku tunggu di sini.", "Oke, sampai jumpa. Jangan lama-lama!" };
    private static final String[] ACK = {
        "Oke!", "Siap!", "Sip, kabarin aja kalau butuh sesuatu.", "Yap!" };
    private static final String[] Q_FALLBACK = {
        "Hmm, pertanyaan bagus. Tapi aku cuma paham soal Minecraft, kayu, dan tambang. Coba ketik \"bantuan\".",
        "Aku belum tahu jawabannya, {p}. Mungkin tanya soal tambang atau mob?",
        "Waduh, itu di luar pengetahuanku. Aku lebih jago nebang pohon!" };
    private static final String[] DEFAULT = {
        "Hmm, aku belum ngerti maksud kamu. Coba ketik \"bantuan\" buat lihat perintahku.",
        "Maaf {p}, aku kurang nangkep. Mau aku ambilin kayu atau nambang?",
        "Aku dengerin kok. Cerita aja lagi, atau kasih aku tugas!", "Hehe, aku belum paham. Coba pakai kalimat lain ya." };
    private static final String[] POKE = {
        "Ya {p}? Ada apa?", "Hm? Kamu manggil aku?", "Aku di sini, {p}! Mau ngapain kita?" };

    private static final String[] GUARD = {
        "Siap {p}! Aku jaga kamu. Monster yang mendekat akan aku hadapi.", "Mode pengawal aktif. Tenang aja, aku di dekatmu." };
    private static final String[] SETHOME = {
        "Oke, tempat ini aku catat sebagai rumah kita.", "Siap, rumah udah ditandai. Bilang \"pulang\" kalau mau aku balik ke sini." };
    private static final String[] GOHOME = {
        "Oke, aku pulang ke rumah dulu.", "Siap, aku balik ke rumah." };
    private static final String[] DEPOSIT = {
        "Oke, aku simpan hasilnya ke peti terdekat.", "Siap, aku cari peti buat nyimpen barang." };
    private static final String[] FARM = {
        "Siap {p}! Aku panen tanaman yang udah matang dan tanam ulang.", "Oke, urusan kebun serahin ke aku." };
    private static final String[] FARM_N = {
        "Siap! Aku panen {k} tanaman.", "Oke, target {k} tanaman. Aku mulai!" };
    private static final String[] REPEAT_NONE = {
        "Belum ada tugas sebelumnya yang bisa aku ulangi.", "Aku belum pernah dikasih tugas, {p}." };
    private static final String[] FRIEND_LOW = {
        "Kita masih baru kenal, tapi aku senang bisa bantu kamu.", "Masih pelan-pelan ya. Sering-sering ajak aku ngobrol!" };
    private static final String[] FRIEND_MID = {
        "Kita udah lumayan akrab, {p}!", "Aku nyaman kerja bareng kamu." };
    private static final String[] FRIEND_HIGH = {
        "Kita sahabat dekat sekarang, {p}. Aku bakal selalu jagain kamu!", "Kamu teman terbaikku di dunia kotak-kotak ini." };
    private static final String[] IDLE_CLOSE = {
        "{p}, makasih udah selalu ngajak aku. Aku senang banget.", "Kalau nggak ada kamu, dunia ini sepi.", "Kita tim yang hebat ya, {p}!" };

    private static final String[] STAY = {
        "Oke, aku tunggu di sini.", "Siap, aku nggak kemana-mana.", "Aku diam di sini. Panggil aja kalau butuh." };
    private static final String[] FOLLOW = {
        "Oke, aku ikut kamu!", "Siap, aku di belakangmu, {p}.", "Yuk jalan!" };
    private static final String[] STOP = {
        "Oke, aku berhenti. Aku ikut kamu lagi.", "Siap, istirahat dulu.", "Sip, tugas dihentikan." };
    private static final String[] NOT_WORKING = {
        "Aku lagi nggak ngerjain apa-apa kok.", "Belum ada tugas buat aku sekarang." };
    private static final String[] EMPTY_BAG = {
        "Tas aku masih kosong nih.", "Belum ada hasil yang bisa aku kasih, {p}." };
    private static final String[] GIVE = {
        "Nih {p}, {k} item buat kamu!", "Ini hasilnya, {k} item. Semoga berguna!" };
    private static final String[] BAG = {
        "Di tas aku ada: {i}.", "Isi tasku sekarang: {i}." };
    private static final String[] WOOD = {
        "Siap {p}! Aku mulai nebang kayu di sekitar sini.", "Oke, urusan kayu serahin ke aku!" };
    private static final String[] WOOD_N = {
        "Siap! Aku ambil {k} batang kayu.", "Oke, target {k} batang kayu. Aku mulai!" };
    private static final String[] MINE = {
        "Siap {p}! Aku mulai nambang {o}.", "Oke, aku cari {o} di sekitar sini." };
    private static final String[] MINE_N = {
        "Siap! Aku tambang {o}, target {k}.", "Oke, target {k} buah {o}. Aku mulai!" };
    private static final String[] WOOD_HINT = {
        "Kayu? Kalau mau aku ambilin, bilang aja \"ambil kayu\" atau \"ambil 20 kayu\".",
        "Butuh kayu, {p}? Bilang \"tebang pohon\" dan aku mulai." };
    private static final String[] ORE_HINT = {
        "Mau aku carikan {o}? Bilang aja \"tambang {o}\".", "Kalau butuh {o}, aku bisa nambangin. Tinggal suruh ya." };

    private static final String[] IDLE = {
        "Dunia ini luas banget ya...", "Aku penasaran ada apa di bawah tanah sana.", "{p}, kita udah punya cukup obor belum?",
        "Jangan lupa simpan barang berharga di peti ya.", "Kalau butuh bantuan, tinggal bilang \"ambil kayu\" atau \"tambang\".",
        "Aku suka jalan-jalan sama kamu, {p}.", "Hmm, enaknya bikin rumah di mana ya?", "Ketik \"bantuan\" kalau lupa perintahku.",
        "Semoga nggak ada creeper hari ini...", "Kalau bosan, ajak aku ngobrol aja!", "Aku masih sehat, darahku {h}/20.",
        "Ayo kita cari diamond suatu hari nanti!" };
    private static final String[] IDLE_WOOD = {
        "Pohonnya masih banyak, tenang aja.", "Kayu itu dasar dari segalanya, {p}.", "Kapak besiku masih tajam!" };
    private static final String[] IDLE_MINE = {
        "Dug dug dug... suara tambang itu menenangkan.", "Semoga ketemu diamond!", "Awas lava di bawah, aku hati-hati kok." };
    private static final String[] IDLE_NIGHT = {
        "Udah gelap... jangan jauh-jauh dari aku ya.", "Malam hari, zombie berkeliaran. Waspada, {p}.", "Mau tidur dulu atau lanjut kerja?" };
    private static final String[] IDLE_RAIN = {
        "Hujan nih. Lumayan adem.", "Kalau hujan deras gini, enaknya nambang di dalam gua." };

    // ======================================================== util
    public static String fmt(CompanionEntity c, ServerPlayerEntity p, String t) {
        return t.replace("{p}", c.getNickname().isEmpty() ? p.getName().getString() : c.getNickname())
                .replace("{n}", c.getName().getString())
                .replace("{h}", String.valueOf((int) Math.ceil(c.getHealth())));
    }

    private static boolean has(String n, String... stems) {
        for (String s : stems) if (n.contains(s)) return true;
        return false;
    }

    private static boolean w(String n, String... words) {
        for (String s : words) if (n.contains(" " + s + " ")) return true;
        return false;
    }

    private static String pick(CompanionEntity c, String[] lines) {
        String r = lines[RNG.nextInt(lines.length)];
        if (lines.length > 1 && r.equals(c.lastLine)) {
            r = lines[(Arrays.asList(lines).indexOf(r) + 1) % lines.length];
        }
        c.lastLine = r;
        return r;
    }

    private static void say(CompanionEntity c, String[] lines) { c.say(pick(c, lines)); }

    private static Integer number(String n) {
        Matcher m = NUM.matcher(n);
        return m.find() ? Integer.valueOf(m.group(1)) : null;
    }

    private static String detectOre(String n) {
        if (has(n, "batu bara", "batubara", "coal")) return "coal";
        if (w(n, "besi", "iron")) return "iron";
        if (w(n, "tembaga", "copper")) return "copper";
        if (w(n, "emas", "gold")) return "gold";
        if (has(n, "berlian", "diamond", "diamon")) return "diamond";
        if (has(n, "redstone")) return "redstone";
        if (has(n, "lapis", "lazuli")) return "lapis";
        if (w(n, "zamrud", "emerald")) return "emerald";
        if (has(n, "kuarsa", "quartz")) return "quartz";
        return null;
    }

    private static String oreLabel(String f) {
        if (f == null || f.isEmpty()) return "ore apa aja";
        return switch (f) {
            case "coal" -> "batu bara"; case "iron" -> "besi"; case "copper" -> "tembaga"; case "gold" -> "emas";
            case "diamond" -> "diamond"; case "redstone" -> "redstone"; case "lapis" -> "lapis lazuli";
            case "emerald" -> "zamrud"; case "quartz" -> "kuarsa"; default -> f;
        };
    }

    private static String oreFact(String f) {
        return switch (f) {
            case "diamond" -> "Di 1.18 diamond paling banyak ada di sekitar Y -59, jadi turun yang dalam.";
            case "iron" -> "Besi paling banyak di sekitar Y 16, dan juga di pegunungan tinggi.";
            case "coal" -> "Batu bara paling banyak di sekitar Y 96 ke atas, tapi di bawah juga ada.";
            case "copper" -> "Tembaga paling banyak di sekitar Y 48, apalagi di dripstone caves.";
            case "gold" -> "Emas paling banyak di sekitar Y -16, dan banyak di badlands.";
            case "redstone" -> "Redstone paling banyak di dasar dunia, sekitar Y -59.";
            case "lapis" -> "Lapis lazuli paling banyak di sekitar Y 0.";
            case "emerald" -> "Zamrud cuma muncul di biom pegunungan.";
            default -> "Ore ini biasanya ada di dalam gua atau di bawah tanah.";
        };
    }

    // ======================================================== teks otomatis dari entity
    public static String poke(CompanionEntity c) { return pick(c, POKE); }

    public static String idleLine(CompanionEntity c, ServerPlayerEntity o) {
        if (o.getHealth() <= 8.0f) return "{p}, darahmu tinggal dikit! Hati-hati ya.";
        if (o.getHungerManager().getFoodLevel() <= 6) return "Perutmu kayaknya udah lapar, {p}. Makan dulu gih.";
        if (c.world.isThundering()) return "Petirnya serem... jangan berdiri di tempat terbuka.";
        if (c.world.isRaining() && RNG.nextInt(3) == 0) return pick(c, IDLE_RAIN);
        if (isNight(c) && RNG.nextInt(3) == 0) return pick(c, IDLE_NIGHT);
        if (c.getMode() == Mode.WOOD && RNG.nextInt(2) == 0) return pick(c, IDLE_WOOD);
        if (c.getMode() == Mode.MINE && RNG.nextInt(2) == 0) return pick(c, IDLE_MINE);
        if (c.getFriendship() >= 70 && RNG.nextInt(4) == 0) return pick(c, IDLE_CLOSE);
        return pick(c, IDLE);
    }

    public static String progress(CompanionEntity c) {
        String unit = c.getMode() == Mode.WOOD ? "batang kayu" : c.getMode() == Mode.FARM ? "tanaman" : oreLabel(c.getOreFilter());
        return "Udah " + c.getProgress() + " " + unit + " yang aku kumpulin!";
    }

    public static String finished(Mode m, String ore, int n) {
        if (m == Mode.FARM) return "Selesai! " + n + " tanaman udah dipanen dan ditanam ulang. Hasilnya di tasku.";
        if (m == Mode.WOOD) return "Selesai! " + n + " batang kayu udah ada di tasku. Ketik \"kasih hasilnya\" kalau mau diambil.";
        return "Selesai! " + n + " buah " + oreLabel(ore) + " udah di tasku. Ketik \"kasih hasilnya\" kalau mau diambil.";
    }

    public static String noTarget(Mode m, String ore) {
        if (m == Mode.FARM) return "Nggak ada tanaman yang udah matang di sekitar sini.";
        if (m == Mode.WOOD) return "Aku nggak nemu pohon yang bisa dijangkau di sekitar sini. Coba kita pindah ke hutan ya.";
        return "Aku nggak nemu " + oreLabel(ore) + " di sekitar sini. Coba ajak aku ke gua atau turun lebih dalam.";
    }

    private static boolean isNight(CompanionEntity c) {
        if (!c.world.getDimension().hasSkyLight()) return false;
        long t = c.world.getTimeOfDay() % 24000L;
        return t >= 13000 && t < 23000;
    }

    private static String timeLine(CompanionEntity c) {
        if (!c.world.getDimension().hasSkyLight()) return "Di dimensi ini nggak ada matahari, susah nebak waktunya.";
        long t = c.world.getTimeOfDay() % 24000L;
        if (t < 6000) return "Masih pagi! Waktu yang pas buat kerja.";
        if (t < 12000) return "Udah siang, matahari lagi tinggi.";
        if (t < 13000) return "Udah sore, bentar lagi gelap.";
        if (t < 23000) return "Udah malam. Zombie mulai bermunculan, hati-hati!";
        return "Hampir subuh, sebentar lagi pagi.";
    }

    private static String weatherLine(CompanionEntity c) {
        if (c.world.isThundering()) return "Lagi badai petir! Cari tempat berlindung, {p}.";
        if (c.world.isRaining()) return "Lagi hujan nih. Basah-basah dikit nggak apa-apa.";
        return "Cuacanya cerah. Cocok buat kerja!";
    }

    private static String statusLine(CompanionEntity c) {
        return switch (c.getMode()) {
            case WOOD -> "Aku lagi nebang pohon buat kamu, udah " + c.getProgress() + " batang.";
            case MINE -> "Aku lagi nambang " + oreLabel(c.getOreFilter()) + ", udah dapat " + c.getProgress() + ".";
            case STAY -> "Aku lagi nunggu di sini sesuai perintahmu.";
            case FARM -> "Aku lagi ngurus kebun, udah " + c.getProgress() + " tanaman dipanen.";
            case GUARD -> "Aku lagi jaga kamu dari monster, {p}.";
            case GOHOME -> "Aku lagi jalan pulang ke rumah.";
            case DEPOSIT -> "Aku lagi nyimpen hasil ke peti.";
            default -> "Lagi ngikutin kamu, {p}. Santai aja.";
        };
    }

    // ======================================================== pintu masuk dari chat
    public static void handle(ServerPlayerEntity p, String raw) {
        List<CompanionEntity> list = TemanMod.findCompanions(p, 32);
        if (list.isEmpty()) return;
        CompanionEntity c = list.stream()
                .min(Comparator.comparingDouble((CompanionEntity e) -> e.squaredDistanceTo(p))).get();
        String clean = raw.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
        if (clean.isEmpty()) return;
        respond(c, p, " " + clean + " ", raw);
    }

    private static void respond(CompanionEntity c, ServerPlayerEntity p, String n, String raw) {
        boolean act = has(n, "ambil", "ngambil", "cari", "kumpul", "tebang", "nebang", "potong", "panen", "gali", "carikan", "cariin")
                || w(n, "tolong", "bantu", "yuk", "ayo", "mulai", "minta", "coba");

        // ---- konteks: jawaban atas pertanyaan sebelumnya
        String ask = c.pendingAsk;
        c.pendingAsk = null;
        if (ask != null && n.trim().split(" ").length <= 4) {
            if (w(n, "ya", "iya", "boleh", "mau", "gas", "yuk", "lanjut", "oke", "ok", "siap", "yoi")) {
                if (ask.equals("WOOD")) {
                    c.startTask(Mode.WOOD, "", 0);
                    say(c, WOOD);
                } else {
                    String o = ask.substring(5);
                    c.startTask(Mode.MINE, o, 0);
                    c.say(pick(c, MINE).replace("{o}", oreLabel(o)));
                }
                return;
            }
            if (w(n, "nggak", "tidak", "gak", "enggak", "ngga", "nanti", "gausah")) {
                c.say("Oke, kalau gitu nggak jadi.");
                return;
            }
        }

        // ---- ingat nama panggilan & nama teman
        Matcher nick = NICK.matcher(raw);
        if (nick.find() && !RESERVED.contains(nick.group(1).toLowerCase(Locale.ROOT))) {
            c.setNickname(nick.group(1));
            c.say("Oke, mulai sekarang aku panggil kamu " + nick.group(1) + "!");
            return;
        }
        Matcher ren = RENAME.matcher(raw);
        if (ren.find() && !RESERVED.contains(ren.group(1).toLowerCase(Locale.ROOT))) {
            c.setCustomName(new LiteralText(ren.group(1)));
            c.say("Hehe, aku suka nama " + ren.group(1) + ". Mulai sekarang itu namaku!");
            return;
        }

        // ---- perintah gerak
        if (has(n, "tetap di sini", "tetap disini", "jangan ikut", "jangan pergi") || w(n, "diam", "tunggu", "stay", "tungguin")) {
            c.setMode(Mode.STAY); say(c, STAY); return;
        }
        if (w(n, "stop", "berhenti", "cukup", "batal", "hentikan", "istirahat")
                || has(n, "jangan tebang", "jangan ambil", "jangan tambang", "jangan nambang")) {
            if (c.isWorking() || c.getMode() == Mode.GUARD || c.getMode() == Mode.GOHOME || c.getMode() == Mode.DEPOSIT) { c.setMode(Mode.FOLLOW); say(c, STOP); } else say(c, NOT_WORKING);
            return;
        }

        // ---- rumah, peti, jaga, ulang, kebun
        if (has(n, "jadikan ini rumah", "tandai rumah", "set home", "sethome", "ini rumahmu", "rumah kita di sini", "base di sini")) {
            c.setHome(p.getBlockPos());
            say(c, SETHOME);
            return;
        }
        if (has(n, "pulang", "balik ke rumah", "ke rumah", "kembali ke rumah", "go home")
                && !has(n, "aku pulang", "saya pulang", "gue pulang")) {
            c.setMode(Mode.GOHOME);
            say(c, GOHOME);
            return;
        }
        if (has(n, "simpan ke peti", "simpan di peti", "taruh di peti", "masukkan ke peti", "masukin ke peti", "ke peti", "simpan hasil")) {
            c.setMode(Mode.DEPOSIT);
            say(c, DEPOSIT);
            return;
        }
        if (has(n, "jaga", "lindungi", "pengawal", "bodyguard", "waspada")) {
            c.setMode(Mode.GUARD);
            say(c, GUARD);
            return;
        }
        if (has(n, "ulangi", "ulang lagi", "sekali lagi", "lanjutkan", "lanjut kerja", "lagi dong")) {
            if (c.lastMode == null) {
                say(c, REPEAT_NONE);
            } else {
                c.startTask(c.lastMode, c.lastOre, c.lastGoal);
                c.say("Oke, aku ulangi tugas tadi!");
            }
            return;
        }
        if (has(n, "statistik", "total kerja", "udah ngerjain berapa", "sudah ngerjain berapa")) {
            c.say("Sejauh ini aku udah menyelesaikan " + c.getTotalWork() + " pekerjaan buat kamu, {p}.");
            return;
        }
        if (has(n, "gandum", "wortel", "kentang", "tanaman", "kebun", "bertani", "berkebun", "farm", "panen")
                && !has(n, "kayu", "tambang", "nambang")) {
            Integer fn = number(n);
            int fg = fn == null ? 0 : Math.max(1, Math.min(fn, 256));
            c.startTask(Mode.FARM, "", fg);
            c.say(pick(c, fg > 0 ? FARM_N : FARM).replace("{k}", String.valueOf(fg)));
            return;
        }

        // ---- tas
        if (has(n, "serahkan", "setor", "berikan", "kasihin", "kasih aku", "kasih semua", "mana hasil", "hasilnya", "keluarkan")) {
            int given = c.giveAllTo(p);
            if (given == 0) say(c, EMPTY_BAG); else c.say(pick(c, GIVE).replace("{k}", String.valueOf(given)));
            return;
        }
        if (has(n, "bawa apa", "punya apa", "isi tas", "inventory", "dapat apa", "dapet apa", "hasil apa",
                "berapa kayu", "berapa banyak", "udah dapat", "sudah dapat")) {
            String sum = c.inventorySummary();
            if (sum == null) say(c, EMPTY_BAG); else c.say(pick(c, BAG).replace("{i}", sum));
            return;
        }

        // ---- tugas kayu / tambang
        boolean woodWord = has(n, "kayu", "pohon", "tebang", "nebang", "batang") || w(n, "log", "wood");
        boolean mineWord = has(n, "tambang", "nambang", "gali", "bijih") || w(n, "ore", "mining", "mine", "mineral");
        String ore = detectOre(n);
        Integer num = number(n);
        int goal = num == null ? 0 : Math.max(1, Math.min(num, 256));

        if (woodWord && !mineWord && (act || has(n, "tebang", "nebang"))) {
            c.startTask(Mode.WOOD, "", goal);
            c.say(pick(c, goal > 0 ? WOOD_N : WOOD).replace("{k}", String.valueOf(goal)));
            return;
        }
        if (mineWord || (ore != null && act)) {
            c.startTask(Mode.MINE, ore == null ? "" : ore, goal);
            c.say(pick(c, goal > 0 ? MINE_N : MINE).replace("{o}", oreLabel(ore)).replace("{k}", String.valueOf(goal)));
            return;
        }
        if (woodWord) { c.pendingAsk = "WOOD"; say(c, WOOD_HINT); return; }
        if (ore != null) {
            c.pendingAsk = "MINE:" + ore;
            c.say(pick(c, ORE_HINT).replace("{o}", oreLabel(ore)));
            c.say(oreFact(ore));
            return;
        }

        // ---- ikut / status
        if (has(n, "ikut", "kesini", "ke sini", "kemari", "datang", "temani") || w(n, "sini")) {
            c.setMode(Mode.FOLLOW);
            if (c.squaredDistanceTo(p) > 256.0) c.teleportNear(p);
            say(c, FOLLOW);
            return;
        }
        if (has(n, "lagi apa", "sedang apa", "ngapain", "lagi ngapain")) { c.say(statusLine(c)); return; }

        // ---- ngobrol
        if (has(n, "selamat pagi", "selamat siang", "selamat sore", "selamat malam")) {
            String part = has(n, "pagi") ? "pagi" : has(n, "siang") ? "siang" : has(n, "sore") ? "sore" : "malam";
            c.say("Selamat " + part + " juga, {p}! " + timeLine(c));
            return;
        }
        if (has(n, "siapa kamu", "kamu siapa", "siapa namamu", "nama kamu", "namamu", "siapa nama")) { say(c, NAME); return; }
        if (has(n, "apa kabar", "gimana kabar", "gmn kabar", "kabarmu", "kabar kamu", "kamu sehat", "kamu baik", "baik baik")) {
            say(c, c.getHealth() < 8.0f ? HOW_HURT : HOW); return;
        }
        if (has(n, "bisa apa", "bantuan", "perintah", "fitur") || w(n, "help", "menu")) {
            c.say("Aku bisa bantu kamu soal ini:");
            c.say("- \"ambil kayu\" atau \"ambil 20 kayu\"");
            c.say("- \"tambang\", \"tambang diamond\", \"cari besi 10\"");
            c.say("- \"ikut aku\", \"tunggu di sini\", \"stop\"");
            c.say("- \"bawa apa?\" dan \"kasih hasilnya\"");
            c.say("- \"panen\" (kebun), \"jaga aku\", \"simpan ke peti\", \"jadikan ini rumah\", \"pulang\"");
            c.say("- \"panggil aku NAMA\", \"ganti namamu jadi NAMA\", \"ulangi\", \"statistik\"");
            c.say("Kasih aku makanan atau obor (klik kanan) buat perbekalan. Atau ajak aja ngobrol!");
            return;
        }
        if (has(n, "makasih", "terima kasih", "terimakasih", "thanks", "thank you", "tengkyu", "trims") || w(n, "thx")) { c.addFriendship(2); say(c, THANKS); return; }
        if (has(n, "hebat", "keren", "pintar", "pinter", "mantap", "bagus", "jago", "good job", "terbaik")) { c.addFriendship(2); say(c, PRAISE); return; }
        if (has(n, "maaf", "sorry", "ampun")) { say(c, SORRY); return; }
        if (has(n, "bodoh", "bego", "tolol", "payah", "jelek", "menyebalkan", "benci")) { c.addFriendship(-5); say(c, HURT); return; }
        if (has(n, "joke", "lawak", "lucu", "bercanda", "hibur")) { say(c, JOKES); return; }
        if (has(n, "fakta", "tau nggak", "tahu nggak", "tau gak", "tahu gak", "info menarik")) { say(c, FACTS); return; }
        if (has(n, "jam berapa", "sekarang siang", "sekarang malam", "udah malam", "sudah malam", "udah pagi", "sudah siang")) { c.say(timeLine(c)); return; }
        if (has(n, "hujan", "cuaca", "petir", "badai", "mendung")) { c.say(weatherLine(c)); return; }
        if (has(n, "creeper", "zombie", "skeleton", "spider", "laba laba", "monster", "musuh", "enderman", "bahaya", "witch")) { say(c, MOBS); return; }
        if (has(n, "nether", "ender dragon", "portal")) { say(c, NETHER); return; }
        if (has(n, "rumah", "bangun", "bikin base")) { say(c, HOUSE); return; }
        if (has(n, "dadah", "sampai jumpa", "bye", "aku pergi", "off dulu", "log out", "tidur dulu", "aku keluar")) { say(c, BYE); return; }
        if (has(n, "lapar", "makan", "steak", "roti")) { say(c, FOOD); return; }
        if (has(n, "tidur", "kasur", "ngantuk") || w(n, "bed")) { say(c, SLEEP); return; }
        if (has(n, "seberapa dekat", "level pertemanan", "kamu suka aku", "kamu sayang aku", "kita dekat")) {
            int f = c.getFriendship();
            c.say("Level pertemanan kita " + f + "/100. " + pick(c, f >= 70 ? FRIEND_HIGH : f >= 40 ? FRIEND_MID : FRIEND_LOW));
            return;
        }
        if (w(n, "teman", "sahabat", "bestie") || has(n, "sayang", "suka kamu")) { say(c, FRIEND); return; }
        if (w(n, "halo", "hai", "hi", "hello", "hei", "hey", "woi", "oi", "oy", "hallo", "permisi") || has(n, "halo", "hallo", "hello")) { say(c, GREET); return; }
        if (w(n, "ya", "iya", "oke", "ok", "sip", "siap", "yoi", "yap", "betul", "benar")) { say(c, ACK); return; }
        if (raw.contains("?") || w(n, "apa", "kenapa", "mengapa", "kapan", "dimana", "bagaimana", "gimana", "siapa", "berapa")) { say(c, Q_FALLBACK); return; }
        say(c, DEFAULT);
    }
}
