package com.teman.client;

import com.teman.entity.CompanionEntity;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.Identifier;

/** Tampilan persis pemain Steve (pakai skin bawaan Minecraft). */
public class CompanionRenderer extends BipedEntityRenderer<CompanionEntity, PlayerEntityModel<CompanionEntity>> {
    private static final Identifier TEXTURE = new Identifier("textures/entity/steve.png");

    public CompanionRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PlayerEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER), false), 0.5f);
        this.addFeature(new ArmorFeatureRenderer<>(this,
                new BipedEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER_INNER_ARMOR)),
                new BipedEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER_OUTER_ARMOR))));
    }

    @Override
    public Identifier getTexture(CompanionEntity entity) {
        return TEXTURE;
    }
}
