package com.teman.client;

import com.teman.TemanMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class TemanClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(TemanMod.COMPANION, CompanionRenderer::new);
    }
}
