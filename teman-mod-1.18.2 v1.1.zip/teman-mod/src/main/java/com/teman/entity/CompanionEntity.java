package com.teman.entity;

import com.teman.chat.ChatBrain;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.tag.ItemTags;
import net.minecraft.text.LiteralText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.ItemScatterer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.ArrayDeque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

public class CompanionEntity extends PathAwareEntity {
    public enum Mode { FOLLOW, STAY, WOOD, MINE, FARM, GUARD, GOHOME, DEPOSIT }

    private static final String[] NAMES = {"Budi", "Andi", "Rian", "Dimas", "Bayu", "Raka", "Fajar", "Joko", "Eko", "Dika"};

    private static class Pending {
        final String text;
        int delay;
        Pending(String text, int delay) { this.text = text; this.delay = delay; }
    }

    private final SimpleInventory inventory = new SimpleInventory(27);   // hasil kerja
    private final SimpleInventory supplies = new SimpleInventory(9);     // obor + makanan
    private final ArrayDeque<Pending> pending = new ArrayDeque<>();
    private UUID ownerUuid;
    private Mode mode = Mode.FOLLOW;
    private String oreFilter = "";
    private int goal;
    private int progress;
    private int talkTimer = 900;
    private int eatCooldown;
    private int friendship = 20;          // 0..100
    private int totalWork;
    private String nickname = "";
    private BlockPos home;

    // konteks percakapan (tidak disimpan)
    public String lastLine = "";
    public String pendingAsk;
    public Mode lastMode;
    public String lastOre = "";
    public int lastGoal;

    public CompanionEntity(EntityType<? extends CompanionEntity> type, World world) {
        super(type, world);
        this.setPersistent();
        this.setCustomName(new LiteralText(NAMES[this.random.nextInt(NAMES.length)]));
        this.setCustomNameVisible(true);
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            this.setEquipmentDropChance(slot, 0f);
        }
        updateHeld();
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 20.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 5.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new MeleeAttackGoal(this, 1.2, true));
        this.goalSelector.add(2, new WorkGoal(this));
        this.goalSelector.add(2, new ErrandGoal(this));
        this.goalSelector.add(3, new FollowOwnerGoal(this));
        this.goalSelector.add(4, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        this.goalSelector.add(5, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, HostileEntity.class, 10, true, false,
                e -> !(e instanceof CreeperEntity)));
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    // ------------------------------------------------------------ tick
    @Override
    public void tick() {
        super.tick();
        if (this.world.isClient) return;

        tickPending();

        if (--talkTimer <= 0) {
            talkTimer = 700 + this.random.nextInt(1400);       // 35 - 105 detik
            ServerPlayerEntity o = getOwnerPlayer();
            if (o != null && this.squaredDistanceTo(o) < 24 * 24) {
                say(ChatBrain.idleLine(this, o));
            }
        }

        if (this.age % 100 == 0 && this.getHealth() < this.getMaxHealth()) {
            this.heal(1.0f);
        }
        if (this.age % 20 == 0) autoEat();
        if (mode == Mode.GUARD && this.age % 10 == 0 && this.getTarget() == null) guardScan();

        if (isWorking() && this.age % 5 == 0) {
            for (ItemEntity ie : this.world.getEntitiesByClass(ItemEntity.class,
                    this.getBoundingBox().expand(2.0, 1.0, 2.0), e -> e.isAlive())) {
                ItemStack rest = inventory.addStack(ie.getStack().copy());
                if (rest.isEmpty()) ie.discard(); else ie.setStack(rest);
            }
        }
    }

    private void guardScan() {
        ServerPlayerEntity o = getOwnerPlayer();
        if (o == null) return;
        List<HostileEntity> list = this.world.getEntitiesByClass(HostileEntity.class,
                o.getBoundingBox().expand(14.0), e -> e.isAlive() && !(e instanceof CreeperEntity));
        HostileEntity best = null;
        double bd = Double.MAX_VALUE;
        for (HostileEntity h : list) {
            double d = h.squaredDistanceTo(o);
            if (d < bd) { bd = d; best = h; }
        }
        if (best != null) this.setTarget(best);
    }

    private void autoEat() {
        if (eatCooldown > 0) { eatCooldown -= 20; return; }
        if (this.getHealth() > this.getMaxHealth() - 6.0f) return;
        for (int i = 0; i < supplies.size(); i++) {
            ItemStack s = supplies.getStack(i);
            if (s.isEmpty() || !s.isFood()) continue;
            FoodComponent fc = s.getItem().getFoodComponent();
            if (fc == null || !fc.getStatusEffects().isEmpty()) continue;
            this.heal(fc.getHunger());
            s.decrement(1);
            this.playSound(SoundEvents.ENTITY_GENERIC_EAT, 1.0f, 1.0f);
            eatCooldown = 60;
            if (this.random.nextInt(3) == 0) say("Nyam... lumayan buat pulihin tenaga.");
            return;
        }
    }

    private void tickPending() {
        Pending head = pending.peek();
        if (head == null) return;
        if (--head.delay > 0) return;
        pending.poll();
        ServerPlayerEntity o = getOwnerPlayer();
        if (o != null) {
            String text = ChatBrain.fmt(this, o, head.text);
            o.sendSystemMessage(new LiteralText("<" + this.getName().getString() + "> " + text), this.getUuid());
        }
    }

    /** Antrekan pesan chat dari teman ({p} = panggilan pemain, {n} = nama teman, {h} = darah). */
    public void say(String text) {
        if (this.world.isClient || text == null || pending.size() >= 8) return;
        pending.add(new Pending(text, 18 + this.random.nextInt(22)));
    }

    // ------------------------------------------------------------ owner & memori
    public UUID getOwnerUuid() { return ownerUuid; }
    public void setOwner(PlayerEntity p) { this.ownerUuid = p.getUuid(); }

    public ServerPlayerEntity getOwnerPlayer() {
        if (ownerUuid == null) return null;
        PlayerEntity p = this.world.getPlayerByUuid(ownerUuid);
        return p instanceof ServerPlayerEntity sp ? sp : null;
    }

    public String getNickname() { return nickname; }
    public void setNickname(String s) { this.nickname = s == null ? "" : s; }
    public int getFriendship() { return friendship; }
    public void addFriendship(int d) { friendship = Math.max(0, Math.min(100, friendship + d)); }
    public int getTotalWork() { return totalWork; }
    public BlockPos getHome() { return home; }
    public void setHome(BlockPos p) { this.home = p.toImmutable(); }

    public void teleportNear(Entity e) {
        for (int i = 0; i < 12; i++) {
            double x = Math.floor(e.getX()) + 0.5 + (i == 0 ? 1 : this.random.nextInt(5) - 2);
            double z = Math.floor(e.getZ()) + 0.5 + (i == 0 ? 0 : this.random.nextInt(5) - 2);
            BlockPos pos = new BlockPos(x, Math.floor(e.getY()), z);
            boolean feet = this.world.getBlockState(pos).getCollisionShape(this.world, pos).isEmpty();
            boolean head = this.world.getBlockState(pos.up()).getCollisionShape(this.world, pos.up()).isEmpty();
            boolean floor = !this.world.getBlockState(pos.down()).getCollisionShape(this.world, pos.down()).isEmpty();
            if (feet && head && floor) {
                this.refreshPositionAndAngles(x, pos.getY(), z, this.getYaw(), this.getPitch());
                this.getNavigation().stop();
                return;
            }
        }
        this.refreshPositionAndAngles(e.getX(), e.getY(), e.getZ(), this.getYaw(), this.getPitch());
        this.getNavigation().stop();
    }

    // ------------------------------------------------------------ tugas
    public Mode getMode() { return mode; }
    public String getOreFilter() { return oreFilter; }
    public int getProgress() { return progress; }
    public boolean isWorking() { return mode == Mode.WOOD || mode == Mode.MINE || mode == Mode.FARM; }
    public boolean isFollowing() { return mode == Mode.FOLLOW || mode == Mode.GUARD; }

    public void setMode(Mode m) {
        this.mode = m;
        this.goal = 0;
        this.progress = 0;
        this.oreFilter = "";
        updateHeld();
        this.getNavigation().stop();
    }

    public void startTask(Mode m, String ore, int goal) {
        this.mode = m;
        this.oreFilter = ore == null ? "" : ore;
        this.goal = goal;
        this.progress = 0;
        this.lastMode = m;
        this.lastOre = this.oreFilter;
        this.lastGoal = goal;
        updateHeld();
        this.getNavigation().stop();
    }

    /** Dipanggil WorkGoal setiap satu target (batang kayu / ore / tanaman) selesai. */
    public void onWorkDone() {
        progress++;
        totalWork++;
        if (goal > 0 && progress >= goal) {
            Mode done = mode;
            int n = progress;
            String ore = oreFilter;
            setMode(Mode.FOLLOW);
            addFriendship(1);
            say(ChatBrain.finished(done, ore, n));
        } else if (progress % 8 == 0) {
            say(ChatBrain.progress(this));
        }
    }

    public void workFailed() {
        Mode m = mode;
        String ore = oreFilter;
        setMode(Mode.FOLLOW);
        say(ChatBrain.noTarget(m, ore));
    }

    private void updateHeld() {
        ItemStack held = switch (mode) {
            case WOOD -> new ItemStack(Items.IRON_AXE);
            case MINE -> new ItemStack(Items.IRON_PICKAXE);
            case FARM -> new ItemStack(Items.IRON_HOE);
            default -> new ItemStack(Items.IRON_SWORD);
        };
        this.equipStack(EquipmentSlot.MAINHAND, held);
    }

    // ------------------------------------------------------------ tas & perbekalan
    public void addToInventory(ItemStack stack) {
        ItemStack rest = inventory.addStack(stack.copy());
        if (!rest.isEmpty()) this.dropStack(rest);
    }

    public void addSupply(ItemStack stack) {
        ItemStack rest = supplies.addStack(stack.copy());
        if (!rest.isEmpty()) addToInventory(rest);
    }

    public boolean takeTorch() {
        for (int i = 0; i < supplies.size(); i++) {
            ItemStack s = supplies.getStack(i);
            if (s.isOf(Items.TORCH)) { s.decrement(1); return true; }
        }
        return false;
    }

    /** Ambil satu bibit pohon dari tas (untuk ditanam ulang), atau null. */
    public BlockState takeSapling() {
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack s = inventory.getStack(i);
            if (!s.isEmpty() && s.isIn(ItemTags.SAPLINGS) && s.getItem() instanceof BlockItem bi) {
                s.decrement(1);
                return bi.getBlock().getDefaultState();
            }
        }
        return null;
    }

    public String inventorySummary() {
        Map<String, Integer> m = new LinkedHashMap<>();
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack s = inventory.getStack(i);
            if (!s.isEmpty()) m.merge(s.getName().getString(), s.getCount(), Integer::sum);
        }
        if (m.isEmpty()) return null;
        return m.entrySet().stream()
                .sorted((a, b) -> b.getValue() - a.getValue())
                .limit(6)
                .map(e -> e.getValue() + " " + e.getKey())
                .collect(Collectors.joining(", "));
    }

    public int giveAllTo(ServerPlayerEntity p) {
        int total = 0;
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack s = inventory.getStack(i);
            if (s.isEmpty()) continue;
            total += s.getCount();
            p.getInventory().offerOrDrop(s.copy());
            inventory.setStack(i, ItemStack.EMPTY);
        }
        return total;
    }

    /** Pindahkan isi tas ke peti/barrel. Mengembalikan jumlah item yang berhasil dipindah. */
    public int depositTo(Inventory to) {
        int moved = 0;
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack s = inventory.getStack(i);
            if (s.isEmpty()) continue;
            ItemStack rest = HopperBlockEntity.transfer(null, to, s.copy(), null);
            moved += s.getCount() - rest.getCount();
            inventory.setStack(i, rest);
        }
        return moved;
    }

    // ------------------------------------------------------------ interaksi
    @Override
    protected ActionResult interactMob(PlayerEntity player, Hand hand) {
        if (hand == Hand.MAIN_HAND && player.getUuid().equals(ownerUuid)) {
            ItemStack held = player.getStackInHand(hand);
            if (!held.isEmpty() && (held.isFood() || held.isOf(Items.TORCH))) {
                if (!this.world.isClient) {
                    ItemStack rest = supplies.addStack(held.copy());
                    int moved = held.getCount() - rest.getCount();
                    if (moved > 0) {
                        if (!player.getAbilities().creativeMode) held.decrement(moved);
                        addFriendship(1);
                        say(held.isOf(Items.TORCH) ? "Makasih obornya, {p}! Aku pasang kalau gelap." : "Makasih makanannya, {p}! Aku simpan buat jaga-jaga.");
                    } else {
                        say("Tempat perbekalanku udah penuh, {p}.");
                    }
                }
                return ActionResult.sidedSuccess(this.world.isClient);
            }
            if (!this.world.isClient) {
                addFriendship(1);
                say(ChatBrain.poke(this));
            }
            return ActionResult.sidedSuccess(this.world.isClient);
        }
        return super.interactMob(player, hand);
    }

    @Override
    public void onDeath(DamageSource source) {
        if (!this.world.isClient) {
            ItemScatterer.spawn(this.world, this.getBlockPos(), inventory);
            ItemScatterer.spawn(this.world, this.getBlockPos(), supplies);
            ServerPlayerEntity o = getOwnerPlayer();
            if (o != null) {
                o.sendSystemMessage(new LiteralText("<" + this.getName().getString() + "> Aku... gugur. Panggil aku lagi dengan /teman panggil."), this.getUuid());
            }
        }
        super.onDeath(source);
    }

    // ------------------------------------------------------------ simpan data
    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        if (ownerUuid != null) nbt.putUuid("Owner", ownerUuid);
        nbt.putString("Mode", mode.name());
        nbt.putString("Ore", oreFilter);
        nbt.putInt("Goal", goal);
        nbt.putInt("Progress", progress);
        nbt.putInt("Friend", friendship);
        nbt.putInt("Total", totalWork);
        nbt.putString("Nick", nickname);
        nbt.put("Inv", inventory.toNbtList());
        nbt.put("Sup", supplies.toNbtList());
        if (home != null) {
            nbt.putInt("HomeX", home.getX());
            nbt.putInt("HomeY", home.getY());
            nbt.putInt("HomeZ", home.getZ());
        }
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.containsUuid("Owner")) ownerUuid = nbt.getUuid("Owner");
        try {
            mode = Mode.valueOf(nbt.getString("Mode"));
        } catch (IllegalArgumentException e) {
            mode = Mode.FOLLOW;
        }
        oreFilter = nbt.getString("Ore");
        goal = nbt.getInt("Goal");
        progress = nbt.getInt("Progress");
        if (nbt.contains("Friend")) friendship = nbt.getInt("Friend");
        totalWork = nbt.getInt("Total");
        nickname = nbt.getString("Nick");
        inventory.readNbtList(nbt.getList("Inv", 10));
        supplies.readNbtList(nbt.getList("Sup", 10));
        if (nbt.contains("HomeX")) home = new BlockPos(nbt.getInt("HomeX"), nbt.getInt("HomeY"), nbt.getInt("HomeZ"));
        updateHeld();
    }
}
