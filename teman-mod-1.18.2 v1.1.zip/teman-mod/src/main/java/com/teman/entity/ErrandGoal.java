package com.teman.entity;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.inventory.Inventory;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.EnumSet;

/** Tugas jalan-jalan: pulang ke rumah (GOHOME) dan menyimpan hasil ke peti (DEPOSIT). */
public class ErrandGoal extends Goal {
    private final CompanionEntity c;
    private BlockPos dest;
    private int stuck;
    private int repath;

    public ErrandGoal(CompanionEntity c) {
        this.c = c;
        this.setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }

    private boolean active() {
        return c.getMode() == CompanionEntity.Mode.GOHOME || c.getMode() == CompanionEntity.Mode.DEPOSIT;
    }

    @Override public boolean canStart() { return active(); }
    @Override public boolean shouldContinue() { return active(); }
    @Override public boolean requiresUpdateEveryTick() { return true; }

    @Override
    public void start() { dest = null; stuck = 0; repath = 0; }

    @Override
    public void stop() { c.getNavigation().stop(); dest = null; }

    @Override
    public void tick() {
        if (!(c.world instanceof ServerWorld w)) return;

        if (c.getMode() == CompanionEntity.Mode.GOHOME) {
            dest = c.getHome();
            if (dest == null) {
                c.setMode(CompanionEntity.Mode.FOLLOW);
                c.say("Aku belum tahu rumahku di mana. Berdiri di tempat yang kamu mau, lalu bilang \"jadikan ini rumah\".");
                return;
            }
            if (c.squaredDistanceTo(Vec3d.ofCenter(dest)) <= 6.0) {
                c.setMode(CompanionEntity.Mode.STAY);
                c.say("Aku udah sampai rumah. Aku tunggu di sini ya, {p}.");
                return;
            }
        } else {
            if (dest == null || !isStorage(w.getBlockState(dest))) {
                dest = findStorage(w);
                if (dest == null) {
                    c.setMode(CompanionEntity.Mode.FOLLOW);
                    c.say("Aku nggak nemu peti atau barrel di dekat sini, {p}.");
                    return;
                }
            }
            if (c.squaredDistanceTo(Vec3d.ofCenter(dest)) <= 10.0) {
                Inventory inv = HopperBlockEntity.getInventoryAt(w, dest);
                int moved = inv == null ? 0 : c.depositTo(inv);
                c.setMode(CompanionEntity.Mode.FOLLOW);
                c.say(moved > 0 ? "Beres! " + moved + " item udah aku simpan di peti." : "Petinya penuh, atau tasku memang kosong.");
                return;
            }
        }

        Vec3d center = Vec3d.ofCenter(dest);
        c.getLookControl().lookAt(center.x, center.y, center.z);
        if (c.getNavigation().isIdle() && --repath <= 0) {
            repath = 20;
            c.getNavigation().startMovingTo(center.x, center.y, center.z, 1.15);
        }
        if (++stuck > 600) {
            c.setMode(CompanionEntity.Mode.FOLLOW);
            c.say("Aku nggak bisa sampai ke sana, {p}. Jalannya buntu.");
        }
    }

    private static boolean isStorage(BlockState st) {
        return st.isOf(Blocks.CHEST) || st.isOf(Blocks.BARREL) || st.isOf(Blocks.TRAPPED_CHEST);
    }

    private BlockPos findStorage(ServerWorld w) {
        ServerPlayerEntity o = c.getOwnerPlayer();
        BlockPos origin = o != null ? o.getBlockPos() : c.getBlockPos();
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -12; dx <= 12; dx++) {
            for (int dz = -12; dz <= 12; dz++) {
                for (int dy = -5; dy <= 5; dy++) {
                    m.set(origin.getX() + dx, origin.getY() + dy, origin.getZ() + dz);
                    if (!isStorage(w.getBlockState(m))) continue;
                    double d = c.squaredDistanceTo(m.getX() + 0.5, m.getY() + 0.5, m.getZ() + 0.5);
                    if (d < bd) { bd = d; best = m.toImmutable(); }
                }
            }
        }
        return best;
    }
}
