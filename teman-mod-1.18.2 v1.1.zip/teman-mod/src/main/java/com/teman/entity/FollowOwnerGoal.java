package com.teman.entity;

import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.EnumSet;

public class FollowOwnerGoal extends Goal {
    private final CompanionEntity c;
    private int recalc;

    public FollowOwnerGoal(CompanionEntity c) {
        this.c = c;
        this.setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }

    @Override
    public boolean canStart() {
        ServerPlayerEntity o = c.getOwnerPlayer();
        return c.isFollowing() && o != null && c.squaredDistanceTo(o) > 25.0;
    }

    @Override
    public boolean shouldContinue() {
        ServerPlayerEntity o = c.getOwnerPlayer();
        return c.isFollowing() && o != null && c.squaredDistanceTo(o) > 9.0;
    }

    @Override
    public boolean requiresUpdateEveryTick() { return true; }

    @Override
    public void start() { recalc = 0; }

    @Override
    public void stop() { c.getNavigation().stop(); }

    @Override
    public void tick() {
        ServerPlayerEntity o = c.getOwnerPlayer();
        if (o == null) return;
        c.getLookControl().lookAt(o, 10.0f, c.getMaxLookPitchChange());
        if (--recalc > 0) return;
        recalc = 10;
        if (c.squaredDistanceTo(o) > 20.0 * 20.0) {
            c.teleportNear(o);
        } else {
            c.getNavigation().startMovingTo(o, 1.2);
        }
    }
}
