package com.teman.entity;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CropBlock;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.tag.BlockTags;
import net.minecraft.tag.FluidTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.RaycastContext;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Mengerjakan tugas di sekitar pemain: menebang kayu (WOOD, sekalian menanam bibit),
 * menambang ore (MINE, memasang obor kalau gelap, menghindari lava), memanen tanaman (FARM, tanam ulang).
 */
public class WorkGoal extends Goal {
    private static final int SEARCH_RADIUS = 16;
    private static final double REACH = 4.4;

    private final CompanionEntity c;
    private final Map<BlockPos, Integer> bad = new HashMap<>();
    private BlockPos target;
    private BlockPos breaking;
    private int breakTicks;
    private int stuck;
    private int searchCd;
    private int repathCd;
    private int emptySearches;

    public WorkGoal(CompanionEntity c) {
        this.c = c;
        this.setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }

    @Override public boolean canStart() { return c.isWorking(); }
    @Override public boolean shouldContinue() { return c.isWorking(); }
    @Override public boolean requiresUpdateEveryTick() { return true; }

    @Override
    public void start() {
        target = null;
        breaking = null;
        searchCd = 0;
        stuck = 0;
        emptySearches = 0;
    }

    @Override
    public void stop() {
        clearCrack();
        target = null;
        c.getNavigation().stop();
    }

    @Override
    public void tick() {
        if (!(c.world instanceof ServerWorld w)) return;
        ServerPlayerEntity owner = c.getOwnerPlayer();

        // jangan terlalu jauh dari pemain
        if (owner != null && c.squaredDistanceTo(owner) > 48.0 * 48.0) {
            c.teleportNear(owner);
            target = null;
            return;
        }

        maybePlaceTorch(w);

        if (target != null && (!matches(w.getBlockState(target)) || isBad(target))) {
            clearCrack();
            target = null;
        }

        if (target == null) {
            if (--searchCd > 0) return;
            searchCd = 20;
            target = find(w, owner);
            breakTicks = 0;
            stuck = 0;
            if (target == null) {
                if (++emptySearches >= 3) {
                    c.workFailed();
                }
                return;
            }
            emptySearches = 0;
        }

        Vec3d center = Vec3d.ofCenter(target);
        c.getLookControl().lookAt(center.x, center.y, center.z);
        double dist = c.getEyePos().distanceTo(center);

        if (dist <= REACH) {
            c.getNavigation().stop();
            BlockPos toBreak = target;
            BlockHitResult hit = w.raycast(new RaycastContext(c.getEyePos(), center,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, c));
            if (hit.getType() == HitResult.Type.BLOCK && !hit.getBlockPos().equals(target)) {
                toBreak = hit.getBlockPos();       // ada penghalang -> gali dulu
            }
            breakBlock(w, toBreak);
            stuck = 0;
        } else {
            if (c.getNavigation().isIdle() && --repathCd <= 0) {
                repathCd = 20;
                c.getNavigation().startMovingTo(center.x, center.y, center.z, 1.15);
            }
            if (++stuck > 400) {               // 20 detik tidak sampai -> lewati target ini
                bad.put(target, c.age + 1200);
                clearCrack();
                target = null;
            }
        }
    }

    /** Pasang obor kalau sedang menambang di tempat gelap (obor diambil dari perbekalan). */
    private void maybePlaceTorch(ServerWorld w) {
        if (c.getMode() != CompanionEntity.Mode.MINE || c.age % 40 != 0) return;
        BlockPos here = c.getBlockPos();
        if (w.getLightLevel(here) > 6) return;
        BlockState torch = Blocks.TORCH.getDefaultState();
        if (w.getBlockState(here).isAir() && torch.canPlaceAt(w, here) && c.takeTorch()) {
            w.setBlockState(here, torch);
        }
    }

    private boolean nearLava(ServerWorld w, BlockPos pos) {
        for (Direction d : Direction.values()) {
            if (w.getFluidState(pos.offset(d)).isIn(FluidTags.LAVA)) return true;
        }
        return false;
    }

    private void breakBlock(ServerWorld w, BlockPos pos) {
        BlockState st = w.getBlockState(pos);
        float hardness = st.getHardness(w, pos);
        if (hardness < 0 || w.getBlockEntity(pos) != null || !st.getFluidState().isEmpty()
                || pos.equals(c.getBlockPos().down()) || nearLava(w, pos)) {
            bad.put(target, c.age + 2400);       // bedrock, peti, lava di dekatnya, atau tanah pijakan: jangan dipecahkan
            clearCrack();
            target = null;
            return;
        }
        if (!pos.equals(breaking)) {
            clearCrack();
            breaking = pos;
            breakTicks = 0;
        }
        int need = Math.max(6, Math.min(100, (int) (hardness * 16)));
        breakTicks++;
        if (breakTicks % 5 == 1) c.swingHand(Hand.MAIN_HAND);
        w.setBlockBreakingInfo(c.getId(), pos, Math.min(9, breakTicks * 10 / need));

        if (breakTicks >= need) {
            Block block = st.getBlock();
            List<ItemStack> drops = Block.getDroppedStacks(st, w, pos, null, c, c.getMainHandStack());
            w.breakBlock(pos, false, c);
            for (ItemStack s : drops) c.addToInventory(s);
            clearCrack();
            if (pos.equals(target)) {
                if (c.getMode() == CompanionEntity.Mode.FARM && block instanceof CropBlock crop) {
                    w.setBlockState(pos, crop.withAge(0));          // tanam ulang
                } else if (c.getMode() == CompanionEntity.Mode.WOOD) {
                    replant(w, pos);
                }
                target = null;
                c.onWorkDone();
            }
        }
    }

    private void replant(ServerWorld w, BlockPos pos) {
        BlockState sap = c.takeSapling();
        if (sap == null) return;
        if (w.getBlockState(pos).isAir() && sap.canPlaceAt(w, pos)) {
            w.setBlockState(pos, sap);
        } else {
            c.addToInventory(new ItemStack(sap.getBlock().asItem()));   // bukan di pangkal pohon: kembalikan
        }
    }

    private void clearCrack() {
        if (breaking != null && c.world instanceof ServerWorld w) {
            w.setBlockBreakingInfo(c.getId(), breaking, -1);
        }
        breaking = null;
        breakTicks = 0;
    }

    private boolean isBad(BlockPos p) {
        Integer until = bad.get(p);
        return until != null && until > c.age;
    }

    private boolean matches(BlockState st) {
        switch (c.getMode()) {
            case WOOD:
                return st.isIn(BlockTags.LOGS);
            case FARM:
                return st.getBlock() instanceof CropBlock crop && crop.isMature(st);
            case MINE:
                String id = Registry.BLOCK.getId(st.getBlock()).getPath();
                String f = c.getOreFilter();
                return id.endsWith("_ore") && (f.isEmpty() || id.contains(f));
            default:
                return false;
        }
    }

    private BlockPos find(ServerWorld w, ServerPlayerEntity owner) {
        BlockPos origin = (owner != null && c.squaredDistanceTo(owner) < 64.0 * 64.0)
                ? owner.getBlockPos() : c.getBlockPos();
        boolean wood = c.getMode() == CompanionEntity.Mode.WOOD;
        boolean mine = c.getMode() == CompanionEntity.Mode.MINE;
        BlockPos best = null;
        double bestScore = Double.MAX_VALUE;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -SEARCH_RADIUS; dx <= SEARCH_RADIUS; dx++) {
            for (int dz = -SEARCH_RADIUS; dz <= SEARCH_RADIUS; dz++) {
                for (int dy = -10; dy <= 10; dy++) {
                    m.set(origin.getX() + dx, origin.getY() + dy, origin.getZ() + dz);
                    BlockState st = w.getBlockState(m);
                    if (!matches(st) || isBad(m)) continue;
                    if (wood && m.getY() > c.getBlockY() + 3) continue;     // kayu yang terlalu tinggi tidak terjangkau
                    double score = c.squaredDistanceTo(m.getX() + 0.5, m.getY() + 0.5, m.getZ() + 0.5);
                    if (mine && !exposed(w, m)) score += 100.0;              // utamakan ore yang kelihatan
                    if (score < bestScore) {
                        bestScore = score;
                        best = m.toImmutable();
                    }
                }
            }
        }
        return best;
    }

    private static boolean exposed(ServerWorld w, BlockPos p) {
        for (Direction d : Direction.values()) {
            if (w.getBlockState(p.offset(d)).isAir()) return true;
        }
        return false;
    }
}
