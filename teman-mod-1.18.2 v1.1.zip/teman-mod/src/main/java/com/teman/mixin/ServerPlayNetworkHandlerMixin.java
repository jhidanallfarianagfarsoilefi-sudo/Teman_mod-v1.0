package com.teman.mixin;

import com.teman.chat.ChatBrain;
import net.minecraft.network.packet.c2s.play.ChatMessageC2SPacket;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerPlayNetworkHandler.class)
public class ServerPlayNetworkHandlerMixin {
    @Shadow public ServerPlayerEntity player;

    @Inject(method = "onChatMessage", at = @At("HEAD"))
    private void teman$onChat(ChatMessageC2SPacket packet, CallbackInfo ci) {
        String msg = packet.getChatMessage();
        if (msg == null || msg.startsWith("/")) return;
        ServerPlayerEntity p = this.player;
        p.getServer().execute(() -> ChatBrain.handle(p, msg));
    }
}
